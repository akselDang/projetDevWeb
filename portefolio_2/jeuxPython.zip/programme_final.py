import copy
import random
from termcolor import colored
# on importe la fonction colored 
# qui nous permet d'afficher des 
# éléments en couleur


def display_map(m,d):
    for i in range(len(m)):
        d[1]=colored("#","green")
        # les murs seront affichés en vert
        for j in range(len(m[i])):
            print(d[m[i][j]],end="")
        print("")

def create_perso(a,b):
    d={"char":"o","x":a,"y":b,"score":0}
    d['char']=colored('o','blue')
    # le personnage sera affiché en bleu
    return d

def display_map_and_char(m,p,d):
    new_map=copy.deepcopy(m)
    # copy.deepcopy permet de copier la map sans la modifier 
    new_map[p['y']][p['x']]=p['char']
    new_dico=d.copy()
    new_dico[p['char']]=p['char']
    return display_map(new_map,new_dico)

def update_p(l,p,m):
    # on verifie avant de faire bouger le personnage
    # que sa prochaine position exitste dans la map
    # et qu'elle est libre
    if l=='z'and (p['y']-1)>-1 and m[p['y']-1][p['x']]!=1:
        p['y']-=1
    elif l=='q' and (p['x']-1)>-1 and m[p['y']][p['x']-1]!=1:
        p['x']-=1
    elif l=='s' and (p['y']+1)<len(m) and m[p['y']+1][p['x']]!=1:
        p['y']+=1
    elif l=='d' and (p['x']+1)<len(m[p['y']]) and m[p['y']][p['x']+1]!=1:
        p['x']+=1
    elif l=='e':
        delete_walls(m,p)

def create_objects(nb_objects,m,p):
    ensemble_objet=set()
    for i in range(nb_objects):
        y=random.randint(0,len(m)-1)
        x=random.randint(0,len(m[y])-1)
        if m[y][x]==0 and (y!=p['y'] or x!=p['x']) :
            objet_coor=(x,y)
            ensemble_objet.add(objet_coor)
    return ensemble_objet

def display_map_char_and_objects(m,p,d,o):
    new_map=copy.deepcopy(m)
    new_map[p['y']][p['x']]=p['char']
    for obj in o:
        new_map[obj[1]][obj[0]]=2
        # on assigne aux objets la key 2 du dictionnaire
        # qui leur associe la valeure '.'
    new_dico=d.copy()
    new_dico[p['char']]=p['char']
    new_dico[2]=colored(".","red")
    # on colore les points en rouge
    display_map(new_map,new_dico)
    print("votre score est de " ,p["score"])
 
def update_objects(p,o):
    coor_perso=(p['x'],p['y'])
    if coor_perso in o:
        o.discard(coor_perso)
        p["score"]+=1

def delete_walls(m,p):
    # meme principe que la fonction update_p
    # on verifie avant de detruire les cases autour
    # du joueur que celles-ci existent et sont des murs 
    if p['x']-1>=0 and m[p['y']][p['x']-1]==1:
        m[p['y']][p['x']-1]=0
    if p['y']-1>=0 and m[p['y']-1][p['x']]==1:
        m[p['y']-1][p['x']]=0
    if p['x']+1<len(m[p['y']]) and m[p['y']][p['x']+1]==1:
        m[p['y']][p['x']+1]=0
    if p['y']+1<len(m) and m[p['y']+1][p['x']]==1:
        m[p['y']+1][p['x']]=0
    if p['x']-1>=0 and p['y']-1>=0 and m[p['y']-1][p['x']-1]==1:
        m[p['y']-1][p['x']-1]=0
    if p['x']+1<len(m[p['y']]) and p['y']+1<len(m) and m[p['y']+1][p['x']+1]==1:
        m[p['y']+1][p['x']+1]=0
    if p['x']+1<len(m[p['y']]) and p['y']-1>=0 and m[p['y']-1][p['x']+1]==1:
        m[p['y']-1][p['x']+1]=0
    if p['x']-1>=0 and p['y']+1<len(m) and m[p['y']+1][p['x']-1]==1:
         m[p['y']+1][p['x']-1]=0
    
def generate_random_map(size_map,proportion_wall):
    map=[]
    # on genere d'abord une map vide de 
    # dimension donné par le joueur
    for i in range(size_map[1]):
        ligne=[]
        for j in range(size_map[0]):
            ligne.append(0)
        map.append(ligne)
    nb_mur=int(proportion_wall*size_map[1]*size_map[0])
    # puis on ajoute un nombre de mur 
    # correspondant à la proportion indiquée
    for i in range(nb_mur):
        x=random.randint(0,size_map[0]-1)
        y=random.randint(0,size_map[1]-1)
        map[y][x]=1
    while(True):
        # on genere des entre et sortie aleatoires 
        # jusqu'a reussite c'est à dire jusqu'a
        # ce que leur position soit libre sur la map
        entre_map_x=random.randint(0,size_map[0]-1)
        entre_map_y=random.randint(0,size_map[1]-1)
        if map[entre_map_y][entre_map_x]==0:
            map[entre_map_y][entre_map_x]=3
            sortie_map_x=random.randint(0,size_map[0]-1)
            sortie_map_y=random.randint(0,size_map[1]-1)
            if map[sortie_map_y][sortie_map_x]==0:
                map[sortie_map_y][sortie_map_x]=4
                break

    

    return map

def create_new_level(p,m,obj,size_map,proportion_wall,d):
    m=generate_random_map(size_map,proportion_wall)
    # on reemplace la map par une nouvelle
    # et on creer des objets en proportions
    # par rapport au nombre de murs ,
    nb_objet=int(proportion_wall*size_map[1]*size_map[0]/2)
    obj=create_objects(nb_objet,m,p)
    # on recherche ensuite l'entree de la map 
    # représenté par un 3 dans le dictionnaire 
    for i in range(len(m)):
        if 3 in m[i]:
            pos_entre_y=i
            for j in range (len(m[i])):
                if j==3:
                    pos_entre_x=j
    # on positionne le joueur à l'entrée
    p=create_perso(pos_entre_x,pos_entre_y)

    return (m,p,d,obj)

# on demande au joueur de donner la taille de la map
# et la proportion de mur souhaité
x_map=0
y_map=0
proportion_wall=-1
while(x_map<1 or y_map<1 or proportion_wall<0 or proportion_wall>1):
    x_map=int(input("entrer le nombre de colone de la map:"))
    y_map=int(input("entrer le nombre de ligne de la map:"))
    size_map=(x_map,y_map)
    proportion_wall=float(input("entrer la proportion de murs:"))

#  on initialise lesvariables de jeu
nb_objet=int(proportion_wall*size_map[1]*size_map[0])
map=generate_random_map(size_map,proportion_wall)
perso=create_perso(0,0)  
dico = {0:' ',1:'#',3:' ',4:' '}    
objet=create_objects(nb_objet,map,perso)
touches_jouables=['z','q','s','d','e']

# on affiche la map puis on rentre dans la boucle de jeu
display_map_char_and_objects(map,perso,dico,objet)
while(True):
            
        
    new_p=input("ou voulez-vous aller?")
    # si la touche saisie est jouable alors on
    # update la pos du joueur et la map
    if new_p in touches_jouables:
        update_p(new_p,perso,map)
        update_objects(perso,objet)
        display_map_char_and_objects(map,perso,dico,objet)
        # si il n'y a plus d'objet alors on affiche
        # la sortie (en bleu)
        if len(objet)==0:
            dico[4]='x'
            dico[4]=colored('x','blue')
            if map[perso['y']][perso['x']]==4:
                # lorsque le personnage arrive a la sortie 
                # on augmente la taille de la map
                # du niveau suivant et on creer le niveau suivant
                # en conservant le score 
                size_map=tuple(x+1 for x in size_map)
                score=perso['score']
                new_tuple=create_new_level(perso,map,objet,size_map,proportion_wall,dico)
                map=new_tuple[0]
                perso=new_tuple[1]
                dico=new_tuple[2]
                objet=new_tuple[3]
                # on remasque la sortie
                dico[4]=' '
                perso['score']+=score
                display_map_char_and_objects(map,perso,dico,objet)
                # on affiche le nouveau niveau
    # si la touche saise est un 1 on termine
    # la partie en affichant le score finale
    elif new_p=="1":
        print("partie terminée votre score est de %d"%(perso['score']))
        break
        
    # si la touche saisie n'est ni jouable ni 1
    # on demande de saisir une nouvelle touche
    else:
        print("veulliez entrer une touche parmi: z q s d e ou tapez fin pour terminer la partie,tapez 1 pour finir la partie")  




