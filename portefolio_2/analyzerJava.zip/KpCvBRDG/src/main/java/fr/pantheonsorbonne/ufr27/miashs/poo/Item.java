package fr.pantheonsorbonne.ufr27.miashs.poo;

import java.lang.Double;
import java.lang.Integer;
import java.lang.String;

public final class Item {
  private Integer rank;

  private String playerName;

  private Integer years;

  private Integer games;

  private Integer minutesPlayed;

  private Integer pointsTotal;

  private Integer reboundsTotal;

  private Integer assistsTotal;

  private Double fieldGoalsPercentage;

  private Double threePointsFieldGoalsPercentage;

  private Double freeThrowPercentage;

  private Double boxPlusMinus;

  public Integer getRank() {
    return this.rank;
  }

  public void setRank(Integer rank) {
    this.rank=rank;
  }

  public String getPlayerName() {
    return this.playerName;
  }

  public void setPlayerName(String playerName) {
    this.playerName=playerName;
  }

  public Integer getYears() {
    return this.years;
  }

  public void setYears(Integer years) {
    this.years=years;
  }

  public Integer getGames() {
    return this.games;
  }

  public void setGames(Integer games) {
    this.games=games;
  }

  public Integer getMinutesPlayed() {
    return this.minutesPlayed;
  }

  public void setMinutesPlayed(Integer minutesPlayed) {
    this.minutesPlayed=minutesPlayed;
  }

  public Integer getPointsTotal() {
    return this.pointsTotal;
  }

  public void setPointsTotal(Integer pointsTotal) {
    this.pointsTotal=pointsTotal;
  }

  public Integer getReboundsTotal() {
    return this.reboundsTotal;
  }

  public void setReboundsTotal(Integer reboundsTotal) {
    this.reboundsTotal=reboundsTotal;
  }

  public Integer getAssistsTotal() {
    return this.assistsTotal;
  }

  public void setAssistsTotal(Integer assistsTotal) {
    this.assistsTotal=assistsTotal;
  }

  public Double getFieldGoalsPercentage() {
    return this.fieldGoalsPercentage;
  }

  public void setFieldGoalsPercentage(Double fieldGoalsPercentage) {
    this.fieldGoalsPercentage=fieldGoalsPercentage;
  }

  public Double getThreePointsFieldGoalsPercentage() {
    return this.threePointsFieldGoalsPercentage;
  }

  public void setThreePointsFieldGoalsPercentage(Double threePointsFieldGoalsPercentage) {
    this.threePointsFieldGoalsPercentage=threePointsFieldGoalsPercentage;
  }

  public Double getFreeThrowPercentage() {
    return this.freeThrowPercentage;
  }

  public void setFreeThrowPercentage(Double freeThrowPercentage) {
    this.freeThrowPercentage=freeThrowPercentage;
  }

  public Double getBoxPlusMinus() {
    return this.boxPlusMinus;
  }

  public void setBoxPlusMinus(Double boxPlusMinus) {
    this.boxPlusMinus=boxPlusMinus;
  }
}
