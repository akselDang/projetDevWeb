package fr.pantheonsorbonne.ufr27.miashs.poo;

import java.lang.String;
import java.util.ArrayList;

public final class ItemsScrapper {
  ArrayList<Item> parseSource(String pageSource) {
    ArrayList<Item> itemList = new ArrayList<>();
    while (true) {
      int idxRank = pageSource.indexOf("class=\"right \" data-stat=\"ranker\">");
      int idxRankEnd = pageSource.indexOf("</th>",idxRank);
      int rank = Integer.parseInt(pageSource.substring(idxRank+34,idxRankEnd));
     
      int idxPlayerName = pageSource.indexOf("<td class=\"left \" data-stat=\"player\"");
      int idxPlayerNameEnd = pageSource.indexOf("</a>",idxPlayerName);
      String playerName = pageSource.substring(idxPlayerName+85 ,idxPlayerNameEnd);

      int idxYears = pageSource.indexOf("class=\"right \" data-stat=\"seasons\">");
      int idxYearsEnd = pageSource.indexOf("</td>",idxYears);
      int years = Integer.parseInt(pageSource.substring(idxYears+35, idxYearsEnd));

      


    


      // add code here
      Item item = new Item();
      item.setRank(rank);
      item.setPlayerName(playerName);
      item.setYears(years);
      item.setGames(null);
      item.setMinutesPlayed(null);
      item.setPointsTotal(null);
      item.setReboundsTotal(null);
      item.setAssistsTotal(null);
      item.setFieldGoalsPercentage(null);
      item.setThreePointsFieldGoalsPercentage(null);
      item.setFreeThrowPercentage(null);
      item.setBoxPlusMinus(null);
      itemList.add(item);
      if(true) {
        // on a fini d'extraire les item
        break;
      }
    }
    return itemList;
  }
  
}
