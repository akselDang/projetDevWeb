package fr.pantheonsorbonne.ufr27.miashs.poo;

import java.lang.Double;
import java.lang.Integer;
import java.util.ArrayList;

public final class ItemAnalyzer {
  private ArrayList<Item> items = new ArrayList<>();

  public ItemAnalyzer(ArrayList<Item> items) {
    this.items=items;
  }

  public Integer getBestGamesNumber() {
    // code here
    return null;
  }

  public Integer getBestAssistsTotal() {
    // code here
    return null;
  }

  public Integer getBestPointsTotal() {
    // code here
    return null;
  }

  public Double getAveragePoints() {
    // code here
    return null;
  }

  public Double getAverageAssists() {
    // code here
    return null;
  }

  public Double getAverageRebounds() {
    // code here
    return null;
  }

  public Double getFieldGoalsPercentageAverage() {
    // code here
    return null;
  }

  public Double getThreePointsFieldGoalsPercentageAverage() {
    // code here
    return null;
  }

  public Double getFreeThrowPercentageAverage() {
    // code here
    return null;
  }

  public Double getBestBoxPlusMinus() {
    // code here
    return null;
  }
}
